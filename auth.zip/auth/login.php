<?php
session_start();
require_once '../functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $found    = $user->findByEmail($email);

    if ($found && $found['is_active'] && password_verify($password, $found['password'])) {
        $_SESSION['user_id'] = $found['id'];
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
    $error = 'Invalid email or password.';
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="min-h-screen flex items-center justify-center bg-gray-50">
<div class="w-full max-w-md bg-white p-8 shadow-sm border border-gray-200">
    <h1 class="text-2xl font-black mb-6">Log In</h1>
    <?php if (!empty($error)): ?>
        <p class="mb-4 text-sm text-red-600"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="POST" class="space-y-4">
        <input type="email"    name="email"    placeholder="Email"    required class="w-full border border-gray-200 px-3 h-10 text-sm outline-none focus:border-black">
        <input type="password" name="password" placeholder="Password" required class="w-full border border-gray-200 px-3 h-10 text-sm outline-none focus:border-black">
        <button type="submit" class="w-full h-10 bg-black text-white text-sm font-bold">Log In</button>
    </form>
    <p class="mt-4 text-sm text-gray-500">No account? <a href="register.php" class="font-bold text-black">Register</a></p>
</div>
</body>
</html>