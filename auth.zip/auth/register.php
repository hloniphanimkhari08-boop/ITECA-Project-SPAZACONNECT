<?php
session_start();
require_once '../functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] === 'seller' ? 'seller' : 'buyer';

    if (!$name || !$email || !$password) {
        $error = 'All fields are required.';
    } elseif ($user->findByEmail($email)) {
        $error = 'Email already registered.';
    } else {
        $id = $user->create($name, $email, $password, $role);
        if ($id) {
            $_SESSION['user_id'] = $id;
            header('Location: ' . BASE_URL . '/index.php');
            exit;
        }
        $error = 'Registration failed. Try again.';
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Register</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="min-h-screen flex items-center justify-center bg-gray-50">
<div class="w-full max-w-md bg-white p-8 shadow-sm border border-gray-200">
    <h1 class="text-2xl font-black mb-6">Create Account</h1>
    <?php if (!empty($error)): ?>
        <p class="mb-4 text-sm text-red-600"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="POST" class="space-y-4">
        <input type="text"     name="name"     placeholder="Full Name"  required class="w-full border border-gray-200 px-3 h-10 text-sm outline-none focus:border-black">
        <input type="email"    name="email"    placeholder="Email"      required class="w-full border border-gray-200 px-3 h-10 text-sm outline-none focus:border-black">
        <input type="password" name="password" placeholder="Password"   required class="w-full border border-gray-200 px-3 h-10 text-sm outline-none focus:border-black">
        <select name="role" class="w-full border border-gray-200 px-3 h-10 text-sm outline-none focus:border-black">
            <option value="buyer">I want to buy</option>
            <option value="seller">I want to sell</option>
        </select>
        <button type="submit" class="w-full h-10 bg-black text-white text-sm font-bold">Register</button>
    </form>
    <p class="mt-4 text-sm text-gray-500">Already have an account? <a href="login.php" class="font-bold text-black">Log in</a></p>
</div>
</body>
</html>