// ── Add to cart ───────────────────────────────────────────────────────────────
document.querySelectorAll('.btn-add-cart').forEach(btn => {
    btn.addEventListener('click', function () {
        const productId  = this.dataset.productId;
        const originalText = this.textContent;

        this.disabled    = true;
        this.textContent = 'Adding...';

        $.ajax({
            url:  window.AppConfig.baseUrl + '/api/cart/add.php',
            type: 'POST',
            data: { product_id: productId },
            success: (res) => {
                const parsed = typeof res === 'string' ? JSON.parse(res) : res;
                if (parsed.success) {
                    const countBadge = document.querySelector('.sc-cart-badge');
                    if (countBadge && parsed.data && typeof parsed.data.count !== 'undefined') {
                        countBadge.textContent = parsed.data.count;
                    }
                } else {
                    alert(parsed.message || 'Error adding to cart.');
                }
            },
            error: () => alert('Request failed.'),
            complete: () => {
                this.disabled    = false;
                this.textContent = originalText;
            }
        });
    });
});

// ── Remove from cart ──────────────────────────────────────────────────────────
document.querySelectorAll('.btn-remove-cart').forEach(btn => {
    btn.addEventListener('click', function () {
        const productId = this.dataset.productId;

        $.ajax({
            url:  window.AppConfig.baseUrl + '/api/cart/remove.php',
            type: 'POST',
            data: { product_id: productId },
            success: (res) => {
                const parsed = typeof res === 'string' ? JSON.parse(res) : res;
                if (parsed.success) {
                    const row = document.getElementById('cart-row-' + productId);
                    if (row) row.remove();

                    const countBadge = document.querySelector('.sc-cart-badge');
                    if (countBadge && parsed.data && typeof parsed.data.count !== 'undefined') {
                        countBadge.textContent = parsed.data.count;
                    }
                } else {
                    alert(parsed.message || 'Error removing item.');
                }
            },
            error: () => alert('Request failed.')
        });
    });
});