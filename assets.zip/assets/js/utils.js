// ── API ───────────────────────────────────────────────────────────────────────
const Api = {
    post(url, data) {
        return new Promise((resolve, reject) => {
            $.post(url, data)
                .done(res => {
                    const parsed = typeof res === 'string' ? JSON.parse(res) : res;
                    parsed.success ? resolve(parsed.data ?? {}) : reject(parsed.message ?? 'Error.');
                })
                .fail(xhr => {
                    if (xhr.status === 401) window.location.href = '/hloni/iteca/auth/login.php';
                    reject('Request failed.');
                });
        });
    }
};

// ── UI ────────────────────────────────────────────────────────────────────────
const UI = {
    loading(btn, isLoading, text = 'Loading...') {
        if (!btn) return;
        if (isLoading) { btn._orig = btn.textContent; btn.textContent = text; btn.disabled = true; }
        else           { btn.textContent = btn._orig ?? ''; btn.disabled = false; }
    },
    cartCount(n) {
        const b = document.getElementById('cart-count');
        if (b) b.textContent = n;
    },
    remove(id) { document.getElementById(id)?.remove(); }
};

// ── Toast ─────────────────────────────────────────────────────────────────────
window.showToast = function (message) {
    const toast = document.getElementById('toast');
    const msg   = document.getElementById('toast-msg');
    if (!toast || !msg) return;
    msg.textContent = message;
    toast.classList.remove('opacity-0', 'translate-y-2');
    toast.classList.add('opacity-100', 'translate-y-0');
    setTimeout(() => {
        toast.classList.remove('opacity-100', 'translate-y-0');
        toast.classList.add('opacity-0', 'translate-y-2');
    }, 3000);
};