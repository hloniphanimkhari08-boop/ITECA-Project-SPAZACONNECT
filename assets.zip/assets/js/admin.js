window.toggleUser = function (id, active, btn) {
    const targetUrl = window.AppConfig.baseUrl + '/api/admin/user-toggle.php';
    
    $.post(targetUrl, { id: id, active: active }, function(data) {
        const nextActiveState = active ? 0 : 1;
        
        btn.textContent = nextActiveState ? 'Deactivate' : 'Activate';
        btn.setAttribute('onclick', `toggleUser(${id}, ${nextActiveState}, this)`);
        
        if (nextActiveState) {
            btn.className = 'action-button-purple';
        } else {
            btn.className = 'action-button-purple';
        }
        
        const row = document.getElementById('user-row-' + id);
        if (row) {
            const statusCell = row.querySelector('.text-cell-muted');
            if (statusCell) {
                statusCell.textContent = active ? 'Inactive' : 'Active';
            }
        }
        
        showToast(active ? 'User deactivated.' : 'User activated.');
    }, 'json').fail(function(xhr) {
        showToast('Failed to toggle user status.');
    });
};

window.removeProduct = function (id, btn) {
    if (!confirm('Remove this product?')) return;
    
    const targetUrl = window.AppConfig.baseUrl + '/api/admin/product-status.php';
    
    $.post(targetUrl, { id: id, status: 'removed' }, function(data) {
        const statusCell = document.getElementById('product-status-' + id);
        if (statusCell) {
            statusCell.textContent = 'Removed';
        }
        
        btn.textContent = 'Restore';
        btn.setAttribute('onclick', `restoreProduct(${id}, this)`);
        btn.className = 'action-button-purple';
        showToast('Product removed.');
    }, 'json').fail(function(xhr) {
        showToast('Failed to remove product.');
    });
};

window.restoreProduct = function (id, btn) {
    const targetUrl = window.AppConfig.baseUrl + '/api/admin/product-status.php';
    
    $.post(targetUrl, { id: id, status: 'active' }, function(data) {
        const statusCell = document.getElementById('product-status-' + id);
        if (statusCell) {
            statusCell.textContent = 'Active';
        }
        
        btn.textContent = 'Remove';
        btn.setAttribute('onclick', `removeProduct(${id}, this)`);
        btn.className = 'action-button-danger';
        showToast('Product restored.');
    }, 'json').fail(function(xhr) {
        showToast('Failed to restore product.');
    });
};

window.updateOrderStatus = function (id, status) {
    const targetUrl = window.AppConfig.baseUrl + '/api/admin/order-status.php';
    
    $.post(targetUrl, { id: id, status: status }, function(data) {
        const cell = document.getElementById('order-status-' + id);
        if (cell) {
            const formattedStatus = status.charAt(0).toUpperCase() + status.slice(1);
            cell.textContent = formattedStatus;
        }
        showToast('Order updated.');
    }, 'json').fail(function(xhr) {
        showToast('Failed to update order status.');
    });
};