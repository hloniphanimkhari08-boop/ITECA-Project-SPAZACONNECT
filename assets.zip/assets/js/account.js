window.markOrderAsDelivered = function (id) {
    if (!id) {
        showToast('Invalid ID.');
        return;
    }

    if (!confirm('Confirm delivery?')) {
        return;
    }

    fetch(`${window.AppConfig.baseUrl}/api/user/mark-delivered.php?order_id=${id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'delivered' })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success || data.status === true) {
            const cell = document.getElementById('order-status-' + id);
            if (cell) {
                cell.textContent = 'Delivered';
                
                const row = cell.closest('.admin-table-row') || cell.closest('tr');
                if (row) {
                    const actionCell = row.querySelector('.action-container') || row.querySelector('div:last-child') || row.querySelector('td:last-child');
                    if (actionCell) {
                        actionCell.className = 'text-cell-muted';
                        actionCell.textContent = 'Finalized';
                    }
                }
            }
            showToast('Order updated.');
        } else {
            showToast(data.message || 'Error.');
        }
    })
    .catch(err => {
        console.error(err);
        showToast('Update failed.');
    });
};

document.getElementById('listing-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    const formData = new FormData(this);
    
    btn.disabled = true;

    const idField = this.querySelector('input[name="id"]');
    const isEditing = !!idField;
    
    let url = window.AppConfig.baseUrl + '/api/product/create.php';
    if (isEditing) {
        url = window.AppConfig.baseUrl + '/api/product/update.php?id=' + idField.value;
    }
    
    $.ajax({
        url: url,
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function(res) {
            const parsed = typeof res === 'string' ? JSON.parse(res) : res;
            if (parsed.success) {
                window.location.href = window.AppConfig.baseUrl + '/account.php';
            } else {
                alert(parsed.message || 'An error occurred.');
                btn.disabled = false;
            }
        },
        error: function() {
            alert('Request failed.');
            btn.disabled = false;
        }
    });
});