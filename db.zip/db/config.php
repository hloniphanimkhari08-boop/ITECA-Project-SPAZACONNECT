<?php

class Config
{
    protected $host = 'sql302.infinityfree.com';
    protected $user = 'if0_42073039';
    protected $password = '2KpsvJACwxzW';
    protected $database = 'if0_42073039_spazaconnect_db';

    public $con = null;

    public function __construct()
    {
        $this->con = mysqli_connect($this->host, $this->user, $this->password, $this->database);
        if($this->con->connect_error){
            echo "Failed to connect to MySQL: " . $this->con->connect_error;
        }
    }

    public function __destruct(){
        $this->closeConnection();
    }
    // close connection
    protected function closeConnection(){
        if($this->con != null){
            $this->con->close();
            $this->con = null;
        }
    }
}

