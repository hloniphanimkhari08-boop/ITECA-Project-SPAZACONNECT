<?php
class Address {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function create(int $userId, array $data): int|false {
        $stmt = $this->db->con->prepare(
            "INSERT INTO addresses (userId, full_name, phone, line1, city, province, postal_code, is_default)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $isDefault = (int)($data['is_default'] ?? 0);
        $stmt->bind_param('issssssi',
            $userId,
            $data['full_name'],
            $data['phone'],
            $data['line1'],
            $data['city'],
            $data['province'],
            $data['postal_code'],
            $isDefault
        );
        return $stmt->execute() ? $this->db->con->insert_id : false;
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->con->prepare("SELECT * FROM addresses WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function getByUser(int $userId): array {
        $stmt = $this->db->con->prepare(
            "SELECT * FROM addresses WHERE userId = ? ORDER BY is_default DESC, id DESC"
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getDefault(int $userId): ?array {
        $stmt = $this->db->con->prepare(
            "SELECT * FROM addresses WHERE userId = ? AND is_default = 1 LIMIT 1"
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function update(int $id, int $userId, array $data): bool {
        $stmt = $this->db->con->prepare(
            "UPDATE addresses SET full_name = ?, phone = ?, line1 = ?, city = ?, province = ?, postal_code = ?, is_default = ?
             WHERE id = ? AND userId = ?"
        );
        $isDefault = (int)($data['is_default'] ?? 0);
        $stmt->bind_param('sssssssii',
            $data['full_name'],
            $data['phone'],
            $data['line1'],
            $data['city'],
            $data['province'],
            $data['postal_code'],
            $isDefault,
            $id,
            $userId
        );
        return $stmt->execute();
    }

    public function delete(int $id, int $userId): bool {
        $stmt = $this->db->con->prepare("DELETE FROM addresses WHERE id = ? AND userId = ?");
        $stmt->bind_param('ii', $id, $userId);
        return $stmt->execute();
    }

    public function setDefault(int $id, int $userId): bool {
        $con = $this->db->con;
        $con->begin_transaction();
        try {
            $stmt = $con->prepare("UPDATE addresses SET is_default = 0 WHERE userId = ?");
            $stmt->bind_param('i', $userId);
            $stmt->execute();

            $stmt = $con->prepare("UPDATE addresses SET is_default = 1 WHERE id = ? AND userId = ?");
            $stmt->bind_param('ii', $id, $userId);
            $stmt->execute();

            $con->commit();
            return true;
        } catch (Exception $e) {
            $con->rollback();
            return false;
        }
    }
}
