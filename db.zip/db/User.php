<?php
class User {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function findById(int $id): ?array {
        $stmt = $this->db->con->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function findByEmail(string $email): ?array {
        $stmt = $this->db->con->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function create(string $name, string $email, string $password, string $role = 'buyer'): int|false {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->con->prepare(
            "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)"
        );
        $stmt->bind_param('ssss', $name, $email, $hash, $role);
        return $stmt->execute() ? $this->db->con->insert_id : false;
    }

    public function getAll(): array {
        $result = $this->db->con->query("SELECT id, name, email, role, is_active, created_at FROM users ORDER BY created_at DESC");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function toggle(int $id, int $active): bool {
        $stmt = $this->db->con->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        $stmt->bind_param('ii', $active, $id);
        return $stmt->execute();
    }
}