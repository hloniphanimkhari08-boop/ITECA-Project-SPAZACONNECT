<?php
class Order {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function create(int $buyerId, float $total, string $address, array $items, string $notes = ''): int|false {
        $con = $this->db->con;
        $con->begin_transaction();

        try {
            $stmt = $con->prepare("INSERT INTO orders (buyer_id, total, address, notes) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('idss', $buyerId, $total, $address, $notes);
            $stmt->execute();
            $orderId = $con->insert_id;
            $stmt->close();

            if (!$orderId || empty($items)) throw new Exception('Invalid order data');

            $itemStmt = $con->prepare("INSERT INTO order_items (order_id, product_id, seller_id, title_snapshot, price_snapshot, quantity) VALUES (?, ?, ?, ?, ?, ?)");
            $prodStmt = $con->prepare("UPDATE products SET status = 'sold' WHERE id = ?");

            foreach ($items as $item) {
                $itemStmt->bind_param('iiisdi', $orderId, $item['product_id'], $item['seller_id'], $item['title_snapshot'], $item['price_snapshot'], $item['quantity']);
                $itemStmt->execute();
                
                $prodStmt->bind_param('i', $item['product_id']);
                $prodStmt->execute();
            }
            $itemStmt->close();
            $prodStmt->close();

            $con->commit();
            return $orderId;
        } catch (\Exception $e) {
            $con->rollback();
            return false;
        }
    }

    public function markPaid(int $orderId, string $pfPaymentId, string $itnPayload): bool {
    $con = $this->db->con;
    
    // 1. Update the orders table status
    $stmt1 = $con->prepare("UPDATE orders SET status = 'paid' WHERE id = ?");
    $stmt1->bind_param('i', $orderId);
    $stmt1->execute();

    // 2. Insert into the payments table
    // We get the amount from the order total first
    $order = $this->findById($orderId);
    $amount = $order['total'] ?? 0;

    $stmt2 = $con->prepare("INSERT INTO payments (orderId, pf_payment_id, amount, status, created_at) VALUES (?, ?, ?, 'completed', NOW())");
    $stmt2->bind_param('isd', $orderId, $pfPaymentId, $amount);
    
    return $stmt2->execute();
}

    public function findById(int $orderId): array|false {
    $stmt = $this->db->con->prepare("SELECT * FROM orders WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $res ?: false;
}

    public function getByUser(int $userId): array {
        $stmt = $this->db->con->prepare("SELECT * FROM orders WHERE buyer_id = ? ORDER BY created_at DESC");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $res;
    }

    public function getItems(int $orderId): array {
        $stmt = $this->db->con->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $res;
    }

    public function getBySeller(int $sellerId): array {
        $stmt = $this->db->con->prepare("SELECT DISTINCT o.*, u.name AS buyer_name FROM orders o JOIN order_items oi ON o.id = oi.order_id JOIN users u ON u.id = o.buyer_id WHERE oi.seller_id = ? ORDER BY o.created_at DESC");
        if (!$stmt) return [];
        $stmt->bind_param('i', $sellerId);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $res;
    }

    public function getAll(): array {
        $result = $this->db->con->query("SELECT o.*, u.name AS buyer_name FROM orders o JOIN users u ON u.id = o.buyer_id ORDER BY o.created_at DESC");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getShippedOrderForBuyer(int $orderId, int $buyerId): array|false {
        $stmt = $this->db->con->prepare("SELECT * FROM orders WHERE id = ? AND buyer_id = ? AND status = 'shipped' LIMIT 1");
        $stmt->bind_param('ii', $orderId, $buyerId);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $res ?: false;
    }

    public function setStatus(int $id, string $status): bool {
        $allowed = ['pending','paid','shipped','delivered','completed','cancelled'];
        if (!in_array($status, $allowed)) return false;
        $stmt = $this->db->con->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param('si', $status, $id);
        $success = $stmt->execute();
        $stmt->close();
        return $success;
    }
}