<?php
class Payment {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function create(int $orderId, float $amount, string $method = 'paygate'): int|false {
        $status = 'pending';
        $stmt = $this->db->con->prepare(
            "INSERT INTO payments (orderId, amount, status, payment_method)
             VALUES (?, ?, ?, ?)"
        );
        $stmt->bind_param('idss',
            $orderId,
            $amount,
            $status,
            $method
        );
        return $stmt->execute() ? $this->db->con->insert_id : false;
    }

    public function getByOrder(int $orderId): ?array {
        $stmt = $this->db->con->prepare("SELECT * FROM payments WHERE orderId = ? LIMIT 1");
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function updateStatus(int $id, string $status, ?string $paymentId = null): bool {
        if (!in_array($status, ['pending', 'complete', 'failed', 'cancelled'])) {
            return false;
        }

        if ($status === 'complete') {
            $stmt = $this->db->con->prepare(
                "UPDATE payments SET status = ?, pf_payment_id = ?, paid_at = NOW() WHERE id = ?"
            );
            $stmt->bind_param('ssi', $status, $paymentId, $id);
        } else {
            $stmt = $this->db->con->prepare("UPDATE payments SET status = ? WHERE id = ?");
            $stmt->bind_param('si', $status, $id);
        }
        return $stmt->execute();
    }

    public function getAll(int $limit = 50, int $offset = 0): array {
        $stmt = $this->db->con->prepare(
            "SELECT p.*, o.buyerId, u.full_name FROM payments p
             JOIN orders o ON o.id = p.orderId
             JOIN users u ON u.id = o.buyerId
             ORDER BY p.created_at DESC
             LIMIT ? OFFSET ?"
        );
        $stmt->bind_param('ii', $limit, $offset);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getStats(): array {
        $result = $this->db->con->query(
            "SELECT
                COUNT(*) AS total_payments,
                SUM(CASE WHEN status = 'complete' THEN 1 ELSE 0 END) AS successful_payments,
                SUM(CASE WHEN status = 'complete' THEN amount ELSE 0 END) AS total_revenue
             FROM payments"
        );
        return $result->fetch_assoc();
    }
}
