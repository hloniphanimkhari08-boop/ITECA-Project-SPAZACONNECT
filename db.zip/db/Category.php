<?php
class Category {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function create(array $data): int|false {
        $stmt = $this->db->con->prepare(
            "INSERT INTO categories (name, slug, description, is_active)
             VALUES (?, ?, ?, 1)"
        );
        $stmt->bind_param('sss',
            $data['name'],
            $data['slug'],
            $data['description']
        );
        return $stmt->execute() ? $this->db->con->insert_id : false;
    }

    public function getAll(bool $activeOnly = true): array {
        $sql = "SELECT * FROM categories";
        if ($activeOnly) $sql .= " WHERE is_active = 1";
        $sql .= " ORDER BY name ASC";
        $result = $this->db->con->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->con->prepare("SELECT * FROM categories WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function getBySlug(string $slug): ?array {
        $stmt = $this->db->con->prepare("SELECT * FROM categories WHERE slug = ? LIMIT 1");
        $stmt->bind_param('s', $slug);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function update(int $id, array $data): bool {
        $stmt = $this->db->con->prepare(
            "UPDATE categories SET name = ?, slug = ?, description = ? WHERE id = ?"
        );
        $stmt->bind_param('sssi',
            $data['name'],
            $data['slug'],
            $data['description'],
            $id
        );
        return $stmt->execute();
    }

    public function toggle(int $id, int $active): bool {
        $stmt = $this->db->con->prepare("UPDATE categories SET is_active = ? WHERE id = ?");
        $stmt->bind_param('ii', $active, $id);
        return $stmt->execute();
    }

    public function delete(int $id): bool {
        $stmt = $this->db->con->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
