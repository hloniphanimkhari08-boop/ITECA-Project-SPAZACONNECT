<?php
class Cart {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function getItems(int $userId): array {
        $stmt = $this->db->con->prepare(
            "SELECT ci.*, p.title, p.price, p.image, p.status, u.name AS seller_name
             FROM cart_items ci
             JOIN products p ON p.id = ci.product_id
             JOIN users u ON u.id = p.seller_id
             WHERE ci.user_id = ? AND p.status = 'active'"
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function add(int $userId, int $productId): bool {
        $stmt = $this->db->con->prepare(
            "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE quantity = quantity + 1"
        );
        $stmt->bind_param('ii', $userId, $productId);
        return $stmt->execute();
    }

    public function update(int $userId, int $productId, int $quantity): bool {
        if ($quantity < 1) return $this->remove($userId, $productId);
        $stmt = $this->db->con->prepare(
            "UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?"
        );
        $stmt->bind_param('iii', $quantity, $userId, $productId);
        return $stmt->execute();
    }

    public function remove(int $userId, int $productId): bool {
        $stmt = $this->db->con->prepare(
            "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?"
        );
        $stmt->bind_param('ii', $userId, $productId);
        return $stmt->execute();
    }

    public function clear(int $userId): bool {
        $stmt = $this->db->con->prepare("DELETE FROM cart_items WHERE user_id = ?");
        $stmt->bind_param('i', $userId);
        return $stmt->execute();
    }

    public function count(int $userId): int {
        $stmt = $this->db->con->prepare(
            "SELECT SUM(quantity) AS total FROM cart_items WHERE user_id = ?"
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    }
}