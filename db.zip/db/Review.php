<?php
class Review {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function create(int $productId, int $userId, int $orderId, int $rating, string $comment = ''): int|false {
        if ($rating < 1 || $rating > 5) return false;

        $stmt = $this->db->con->prepare(
            "INSERT INTO reviews (productId, userId, orderId, rating, comment, approved)
             VALUES (?, ?, ?, ?, ?, 1)"
        );
        $stmt->bind_param('iiiis',
            $productId,
            $userId,
            $orderId,
            $rating,
            $comment
        );
        return $stmt->execute() ? $this->db->con->insert_id : false;
    }

    public function getByProduct(int $productId, int $limit = 10, int $offset = 0): array {
        $stmt = $this->db->con->prepare(
            "SELECT r.*, u.full_name, u.avatar_path FROM reviews r
             JOIN users u ON u.id = r.userId
             WHERE r.productId = ? AND r.approved = 1
             ORDER BY r.created_at DESC
             LIMIT ? OFFSET ?"
        );
        $stmt->bind_param('iii', $productId, $limit, $offset);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function countByProduct(int $productId): int {
        $stmt = $this->db->con->prepare(
            "SELECT COUNT(*) AS total FROM reviews WHERE productId = ? AND approved = 1"
        );
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        return (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    }

    public function getAverage(int $productId): float {
        $stmt = $this->db->con->prepare(
            "SELECT AVG(rating) AS average FROM reviews WHERE productId = ? AND approved = 1"
        );
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return (float)($result['average'] ?? 0);
    }

    public function userCanReview(int $productId, int $userId): bool {
        $stmt = $this->db->con->prepare(
            "SELECT COUNT(*) AS count FROM order_items oi
             JOIN orders o ON o.id = oi.orderId
             WHERE oi.productId = ? AND o.buyerId = ? AND o.status = 'completed'
             LIMIT 1"
        );
        $stmt->bind_param('ii', $productId, $userId);
        $stmt->execute();
        return (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0) > 0;
    }

    public function hasReviewed(int $productId, int $userId): bool {
        $stmt = $this->db->con->prepare(
            "SELECT COUNT(*) AS count FROM reviews WHERE productId = ? AND userId = ?"
        );
        $stmt->bind_param('ii', $productId, $userId);
        $stmt->execute();
        return (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0) > 0;
    }

    public function getAll(int $limit = 20, int $offset = 0): array {
        $stmt = $this->db->con->prepare(
            "SELECT r.*, u.full_name, p.title FROM reviews r
             JOIN users u ON u.id = r.userId
             JOIN products p ON p.id = r.productId
             ORDER BY r.created_at DESC
             LIMIT ? OFFSET ?"
        );
        $stmt->bind_param('ii', $limit, $offset);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function approve(int $id): bool {
        $stmt = $this->db->con->prepare("UPDATE reviews SET approved = 1 WHERE id = ?");
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }

    public function reject(int $id): bool {
        $stmt = $this->db->con->prepare("UPDATE reviews SET approved = 0 WHERE id = ?");
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
