<?php
class Product {
    private $db;

    public function __construct($db) { $this->db = $db; }

    public function getAll(array $opts = []): array {
        // If a specific status filter is passed, use it; otherwise default to active listings
        $statusFilter = $opts['status'] ?? 'active';
        
        $where  = [];
        $params = [];
        $types  = '';

        // Allow bypassing the status check if 'all' is explicitly requested
        if ($statusFilter !== 'all') {
            $where[] = "p.status = ?";
            $params[] = $statusFilter;
            $types .= 's';
        }

        if (!empty($opts['q'])) {
            $like     = '%' . $opts['q'] . '%';
            $where[]  = '(p.title LIKE ? OR p.description LIKE ?)';
            $params[] = $like;
            $params[] = $like;
            $types   .= 'ss';
        }

        if (!empty($opts['seller_id'])) {
            $where[]  = 'p.seller_id = ?';
            $params[] = (int)$opts['seller_id'];
            $types   .= 'i';
        }

        if (!empty($opts['category_id'])) {
            $where[]  = 'p.category_id = ?';
            $params[] = (int)$opts['category_id'];
            $types   .= 'i';
        }

        if (empty($opts['category_id']) && !empty($opts['category'])) {
            $where[]  = '(c.slug = ? OR c.name = ?)';
            $params[] = $opts['category'];
            $params[] = $opts['category'];
            $types   .= 'ss';
        }

        $orderBy = match($opts['sort'] ?? 'newest') {
            'price_asc'  => 'p.price ASC',
            'price_desc' => 'p.price DESC',
            default      => 'p.created_at DESC',
        };

        $whereClause = !empty($where) ? "WHERE " . implode(' AND ', $where) : "";

        $sql  = "SELECT p.*, u.name AS seller_name, c.name AS category_name 
                 FROM products p 
                 JOIN users u ON u.id = p.seller_id 
                 LEFT JOIN categories c ON c.id = p.category_id 
                 $whereClause 
                 ORDER BY $orderBy";
                 
        $stmt = $this->db->con->prepare($sql);
        if (!empty($params)) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->con->prepare(
            "SELECT p.*, u.name AS seller_name, c.name AS category_name 
             FROM products p 
             JOIN users u ON u.id = p.seller_id 
             LEFT JOIN categories c ON c.id = p.category_id 
             WHERE p.id = ? LIMIT 1"
        );
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function create(int $sellerId, array $data): int|false {
        $title       = $data['title'] ?? '';
        $description = $data['description'] ?? '';
        $price       = $data['price'] ?? 0.0;
        $condition   = $data['condition'] ?? 'good';
        $image       = $data['image'] ?? '';
        $categoryId  = (int)($data['category_id'] ?? 0);
        $status      = $data['status'] ?? 'active';

        $stmt = $this->db->con->prepare(
            "INSERT INTO products (`seller_id`, `category_id`, `title`, `description`, `price`, `condition`, `image`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        
        $stmt->bind_param('iissdsss',
            $sellerId,
            $categoryId,
            $title,
            $description,
            $price,
            $condition,
            $image,
            $status
        );
        
        return $stmt->execute() ? $this->db->con->insert_id : false;
    }

    public function update(int $id, array $data): bool {
        $title       = $data['title'] ?? '';
        $description = $data['description'] ?? '';
        $price       = $data['price'] ?? 0.0;
        $condition   = $data['condition'] ?? 'good';
        $sellerId    = $data['seller_id'] ?? 0;
        $categoryId  = (int)($data['category_id'] ?? 0);
        $status      = $data['status'] ?? 'active';

        // Synchronized query updating status values alongside form alterations
        $stmt = $this->db->con->prepare(
            "UPDATE products SET `category_id` = ?, `title` = ?, `description` = ?, `price` = ?, `condition` = ?, `status` = ? WHERE `id` = ? AND `seller_id` = ?"
        );
        
        $stmt->bind_param('issdssii',
            $categoryId,
            $title,
            $description,
            $price,
            $condition,
            $status,
            $id,
            $sellerId
        );
        
        return $stmt->execute();
    }

    public function setStatus(int $id, string $status, int $sellerId): bool {
        $allowed = ['active', 'inactive', 'removed', 'sold'];
        if (!in_array($status, $allowed)) return false;
        
        $stmt = $this->db->con->prepare("UPDATE products SET status = ? WHERE id = ? AND seller_id = ?");
        $stmt->bind_param('sii', $status, $id, $sellerId);
        return $stmt->execute();
    }

    public function setStatusAdmin(int $id, string $status): bool {
        $allowed = ['active', 'inactive', 'removed', 'sold'];
        if (!in_array($status, $allowed)) return false;
        
        $stmt = $this->db->con->prepare("UPDATE products SET status = ? WHERE id = ?");
        $stmt->bind_param('si', $status, $id);
        return $stmt->execute();
    }

    public function getAllAdmin(): array {
        $result = $this->db->con->query(
            "SELECT p.*, u.name AS seller_name, c.name AS category_name 
             FROM products p 
             JOIN users u ON u.id = p.seller_id 
             LEFT JOIN categories c ON c.id = p.category_id 
             ORDER BY p.created_at DESC"
        );
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}