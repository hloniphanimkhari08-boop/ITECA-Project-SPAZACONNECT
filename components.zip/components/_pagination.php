<?php
function renderPagination(string $tableId, int $rowsPerPage = 5) {
    ?>
    <div id="<?= $tableId ?>-pagination" class="flex items-center justify-between px-4 py-3 border-t border-gray-100 bg-gray-50 text-xs text-gray-500">
        <div>
            Showing <span id="<?= $tableId ?>-range-start" class="font-semibold text-gray-900">0</span> to 
            <span id="<?= $tableId ?>-range-end" class="font-semibold text-gray-900">0</span> of 
            <span id="<?= $tableId ?>-total-count" class="font-semibold text-gray-900">0</span> records
        </div>
        <div class="flex gap-1">
            <button id="<?= $tableId ?>-prev" class="px-3 h-7 bg-white border border-gray-200 text-gray-700 rounded transition-opacity hover:opacity-80 disabled:opacity-40 disabled:cursor-not-allowed">
                Previous
            </button>
            <button id="<?= $tableId ?>-next" class="px-3 h-7 bg-white border border-gray-200 text-gray-700 rounded transition-opacity hover:opacity-80 disabled:opacity-40 disabled:cursor-not-allowed">
                Next
            </button>
        </div>
    </div>

    <script>
    (function() {
        const tableId = "<?= $tableId ?>";
        const rowsPerPage = <?= $rowsPerPage ?>;

        function initComponent() {
            const table = document.getElementById(tableId);
            if (!table) return;

            const tbody = table.querySelector('tbody');
            if (!tbody || tbody.querySelectorAll('tr').length === 0) {
                setTimeout(initComponent, 50);
                return;
            }

            const rows = Array.from(tbody.querySelectorAll('tr'));
            let currentPage = 1;
            const totalRows = rows.length;
            const totalPages = Math.ceil(totalRows / rowsPerPage);

            function updateDisplay() {
                if (totalRows === 0) {
                    document.getElementById(`${tableId}-range-start`).textContent = 0;
                    document.getElementById(`${tableId}-range-end`).textContent = 0;
                    document.getElementById(`${tableId}-total-count`).textContent = 0;
                    return;
                }

                const start = (currentPage - 1) * rowsPerPage;
                const end = Math.min(start + rowsPerPage, totalRows);

                rows.forEach((row, idx) => {
                    row.style.display = (idx >= start && idx < end) ? '' : 'none';
                });

                document.getElementById(`${tableId}-range-start`).textContent = start + 1;
                document.getElementById(`${tableId}-range-end`).textContent = end;
                document.getElementById(`${tableId}-total-count`).textContent = totalRows;

                document.getElementById(`${tableId}-prev`).disabled = (currentPage === 1);
                document.getElementById(`${tableId}-next`).disabled = (currentPage === totalPages || totalPages === 0);
            }

            document.getElementById(`${tableId}-prev`).addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage--;
                    updateDisplay();
                }
            });

            document.getElementById(`${tableId}-next`).addEventListener('click', () => {
                if (currentPage < totalPages) {
                    currentPage++;
                    updateDisplay();
                }
            });

            updateDisplay();
        }

        if (window.jQuery) {
            $(document).ready(initComponent);
        } else {
            document.addEventListener('DOMContentLoaded', initComponent);
        }
    })();
    </script>
    <?php
}
?>