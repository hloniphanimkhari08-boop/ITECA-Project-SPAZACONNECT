<?php
require_once '../_admin-guard.php';

header('Content-Type: application/json');

$id     = (int)($_POST['id']     ?? 0);
$status = trim($_POST['status']  ?? '');

if (!$id || !$status) {
    echo json_encode(['success' => false, 'message' => 'Missing fields.']);
    exit;
}

// Call the new admin-specific function that overrides the seller boundary rule
if ($product->setStatusAdmin($id, $status)) {
    echo json_encode(['success' => true, 'message' => 'Product status updated by administrator.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update database record.']);
}
exit;