<?php
session_start();
require_once '../../functions.php';

// Admin only
require_once '../_admin-guard.php';

$method = $_SERVER['REQUEST_METHOD'];
$productId = $_GET['product_id'] ?? null;

if (empty($productId)) {
    api_error('Product ID required');
}

if ($method === 'POST') {
    $action = $_GET['action'] ?? null;

    if ($action === 'remove') {
        $stmt = $db->con->prepare("UPDATE products SET status = 'inactive' WHERE id = ?");
        $stmt->bind_param('i', $productId);
        
        if ($stmt->execute()) {
            api_success([], 'Product removed');
        } else {
            api_error('Failed to remove product');
        }

    } elseif ($action === 'activate') {
        $stmt = $db->con->prepare("UPDATE products SET status = 'active' WHERE id = ?");
        $stmt->bind_param('i', $productId);
        
        if ($stmt->execute()) {
            api_success([], 'Product activated');
        } else {
            api_error('Failed to activate product');
        }

    } elseif ($action === 'delete') {
        $stmt = $db->con->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param('i', $productId);
        
        if ($stmt->execute()) {
            api_success([], 'Product deleted');
        } else {
            api_error('Failed to delete product');
        }

    } else {
        api_error('Invalid action');
    }

} else {
    api_error('Method not allowed', 405);
}
