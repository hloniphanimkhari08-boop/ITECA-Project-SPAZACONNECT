<?php
session_start();
require_once '../../functions.php';

// Admin only
require_once '../_admin-guard.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Get all products
    $limit = (int)($_GET['limit'] ?? 50);
    $offset = (int)($_GET['offset'] ?? 0);
    $status = $_GET['status'] ?? 'all';

    $where = [];
    $types = '';
    $params = [];

    if ($status !== 'all') {
        $where[] = "p.status = ?";
        $types .= 's';
        $params[] = $status;
    }

    $whereClause = !empty($where) ? "WHERE " . implode(' AND ', $where) : '';

    $query = "SELECT p.*, u.full_name AS seller_name FROM products p JOIN users u ON u.id = p.sellerId $whereClause ORDER BY p.created_at DESC LIMIT ? OFFSET ?";
    
    $stmt = $db->con->prepare($query);
    $types .= 'ii';
    $params[] = $limit;
    $params[] = $offset;
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    api_success([
        'products' => $products
    ], 'Products retrieved');

} else {
    api_error('Method not allowed', 405);
}
