<?php
session_start();
require_once '../../functions.php';

// Admin only
require_once '../_admin-guard.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Get all users
    $limit = (int)($_GET['limit'] ?? 50);
    $offset = (int)($_GET['offset'] ?? 0);
    $role = $_GET['role'] ?? null;

    $where = [];
    $types = '';
    $params = [];

    if ($role) {
        $where[] = "role = ?";
        $types .= 's';
        $params[] = $role;
    }

    $where[] = "is_active = 1";
    $whereClause = implode(' AND ', $where);

    $query = "SELECT id, full_name, email, phone, role, is_active, created_at FROM users WHERE $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?";
    
    $stmt = $db->con->prepare($query);
    $types .= 'ii';
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Get count
    $countQuery = "SELECT COUNT(*) AS total FROM users WHERE $whereClause";
    $countStmt = $db->con->prepare($countQuery);
    if ($role) {
        $countStmt->bind_param('s', $role);
    }
    $countStmt->execute();
    $count = $countStmt->get_result()->fetch_assoc()['total'];

    api_success([
        'users' => $users,
        'total' => $count
    ], 'Users retrieved');

} else {
    api_error('Method not allowed', 405);
}
