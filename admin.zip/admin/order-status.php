<?php
require_once '../_admin-guard.php';

$id     = (int)($_POST['id']    ?? 0);
$status = trim($_POST['status'] ?? '');
if (!$id || !$status) api_error('Missing fields.');

$order->setStatus($id, $status);
api_success([], 'Order status updated.');