<?php
require_once '../_admin-guard.php';

$id     = (int)($_POST['id']     ?? 0);
$active = (int)($_POST['active'] ?? 0);
if (!$id) api_error('Invalid user.');

$user->toggle($id, $active);
api_success([], $active ? 'User activated.' : 'User deactivated.');