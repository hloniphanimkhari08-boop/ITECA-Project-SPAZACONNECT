<?php
session_start();
require_once '../../functions.php';

// Admin only
require_once '../_admin-guard.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Get all orders
    $limit = (int)($_GET['limit'] ?? 50);
    $offset = (int)($_GET['offset'] ?? 0);
    $status = $_GET['status'] ?? 'all';

    $where = [];
    $types = '';
    $params = [];

    if ($status !== 'all') {
        $where[] = "o.status = ?";
        $types .= 's';
        $params[] = $status;
    }

    $whereClause = !empty($where) ? "WHERE " . implode(' AND ', $where) : '';

    $query = "SELECT o.*, u.full_name AS buyer_name, COUNT(oi.id) AS item_count FROM orders o 
              JOIN users u ON u.id = o.buyerId 
              LEFT JOIN order_items oi ON oi.orderId = o.id
              $whereClause GROUP BY o.id ORDER BY o.created_at DESC LIMIT ? OFFSET ?";
    
    $stmt = $db->con->prepare($query);
    $types .= 'ii';
    $params[] = $limit;
    $params[] = $offset;
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    api_success([
        'orders' => $orders
    ], 'Orders retrieved');

} else {
    api_error('Method not allowed', 405);
}
