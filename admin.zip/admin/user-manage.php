<?php
session_start();
require_once '../../functions.php';

// Admin only
require_once '../_admin-guard.php';

$method = $_SERVER['REQUEST_METHOD'];
$userId = $_GET['user_id'] ?? null;

if (empty($userId)) {
    api_error('User ID required');
}

if ($method === 'POST') {
    $action = $_GET['action'] ?? null;

    if ($action === 'suspend') {
        $stmt = $db->con->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
        $stmt->bind_param('i', $userId);
        
        if ($stmt->execute()) {
            api_success([], 'User suspended');
        } else {
            api_error('Failed to suspend user');
        }

    } elseif ($action === 'activate') {
        $stmt = $db->con->prepare("UPDATE users SET is_active = 1 WHERE id = ?");
        $stmt->bind_param('i', $userId);
        
        if ($stmt->execute()) {
            api_success([], 'User activated');
        } else {
            api_error('Failed to activate user');
        }

    } elseif ($action === 'delete') {
        $stmt = $db->con->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param('i', $userId);
        
        if ($stmt->execute()) {
            api_success([], 'User deleted');
        } else {
            api_error('Failed to delete user');
        }

    } else {
        api_error('Invalid action');
    }

} else {
    api_error('Method not allowed', 405);
}
